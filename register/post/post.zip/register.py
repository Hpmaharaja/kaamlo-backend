import uuid
import jwt
import time

from passlib.hash import argon2
import pymysql.cursors

# grab our jwt secret wich will be the word secret for now
jwt_secret = 'secret'

def register_handler(event, context):
    # load the data from the post request
    username = event['username']
    password = event['password']
    first_name = event['firstName']
    last_name = event['lastName']
    email = event['email']

    #generate a unique user_id for the user
    user_id = str(uuid.uuid4())

    # hash the user's password
    hashed_password = argon2.using(rounds=4).hash(password)

    # invoke a mysql connection and attempt to add it
    connection = pymysql.connect(
        host="mvp1-kaamlo-logintable.cczywhkujcku.us-west-2.rds.amazonaws.com",
        user="kaamlo",
        password="Radhe108!",
        db="kaamlo")

    with connection.cursor() as cursor:

        # create a tuple of values to insert in to the database
        values = (user_id, username, hashed_password, email, first_name, last_name)

        # insert into the database
        cursor.execute("""INSERT INTO kaamlo-login (user_id, username, password, email, first_name, last_name)
        VALUES (%s, %s, %s, %s, %s, %s)""", values)

    # calculate the expiration time of this token
    expiresAt = time.time() + 3600

    # create the JSON payload to return
    jwt_payload = {
        'userId': user_id,
        'exp': expiresAt
    }

    # create the jwt
    jwt_token = jwt.encode(jwt_payload, secret, algorithm='HS256')

    # return the token
    return {
        'token': jwt_token,
        'expiresIn': 3600
    }
