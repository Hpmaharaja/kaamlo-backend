from aws_srp import AWSSRP
import os

def login_handler(event, context):
    username = event['username']
    password = event['password']

    client_id = os.environ['client_id']
    pool_id = os.environ['pool_id']


    try:
        loginClient = AWSSRP(username, password, pool_id, client_id)
        print(loginClient.authenticate_user())

        return {
            'ExpiresIn': loginClient['ExpiresIn'],
            'IdToken': loginClient['IdToken']
        }

    except Exception as e:

        print(e)
